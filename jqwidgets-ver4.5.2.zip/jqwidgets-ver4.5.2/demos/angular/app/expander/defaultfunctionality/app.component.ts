 
import { Component } from '@angular/core';

import { jqxExpanderComponent } from '../../../../../jqwidgets-ts/angular_jqxexpander';

@Component({
    selector: 'my-app',
    templateUrl: `../app/expander/defaultfunctionality/app.component.htm`
})

export class AppComponent
{ 
 
}
