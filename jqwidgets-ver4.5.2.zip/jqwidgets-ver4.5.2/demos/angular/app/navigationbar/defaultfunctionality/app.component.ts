﻿ 
import { Component } from '@angular/core';

import { jqxNavigationBarComponent } from '../../../../../jqwidgets-ts/angular_jqxnavigationbar';

@Component({
    selector: 'my-app',
    templateUrl: '../app/navigationbar/defaultfunctionality/app.component.htm'
})

export class AppComponent
{

}
