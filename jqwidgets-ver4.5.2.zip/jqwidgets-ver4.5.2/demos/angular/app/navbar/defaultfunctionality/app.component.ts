﻿ 
import { Component } from '@angular/core';

import { jqxNavBarComponent } from '../../../../../jqwidgets-ts/angular_jqxnavbar';

@Component({
    selector: 'my-app',
    templateUrl: '../app/navbar/defaultfunctionality/app.component.htm'
})

export class AppComponent
{

}
