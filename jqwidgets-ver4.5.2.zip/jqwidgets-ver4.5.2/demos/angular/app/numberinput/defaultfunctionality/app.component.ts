﻿ 
import { Component } from '@angular/core';

import { jqxNumberInputComponent } from '../../../../../jqwidgets-ts/angular_jqxnumberinput';

@Component({
    selector: 'my-app',
    templateUrl: '../app/numberinput/defaultfunctionality/app.component.htm'
})

export class AppComponent
{

}