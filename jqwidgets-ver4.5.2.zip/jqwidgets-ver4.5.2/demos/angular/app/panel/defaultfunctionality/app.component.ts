﻿ 
import { Component } from '@angular/core';

import { jqxPanelComponent } from '../../../../../jqwidgets-ts/angular_jqxpanel';

@Component({
    selector: 'my-app',
    templateUrl: '../app/panel/defaultfunctionality/app.component.htm'
})

export class AppComponent
{

}
