 
import { Component } from '@angular/core';

import { jqxDateTimeInputComponent } from '../../../../../jqwidgets-ts/angular_jqxdatetimeinput';

@Component({
    selector: 'my-app',
    templateUrl: `../app/datetimeinput/defaultfunctionality/app.component.htm`
}) 

export class AppComponent
{ 

}
