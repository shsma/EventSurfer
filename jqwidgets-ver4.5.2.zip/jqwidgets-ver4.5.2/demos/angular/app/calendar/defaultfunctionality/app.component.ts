 
import { Component } from '@angular/core';

import { jqxCalendarComponent } from '../../../../../jqwidgets-ts/angular_jqxcalendar';

@Component({
    selector: 'my-app',
    template: `<jqxCalendar [width]='220' [height]='220'></jqxCalendar>`
}) 

export class AppComponent
{ 
}
